function resetExpandIcon(params = "add_circle") {
    $('#scrollicon').html(params);
}

function toggleExpandIcon(params = true) {
    if (params) {
        $('#scrollicon').hide();
    } else {
        $('#scrollicon').show();
    }
}
(function ($) {
    var windowHeight = $(window).height();
    $(document).ready(function () {
        $('#scrollicon', document).on('click', function (e) {
            $('html, body').animate({
                scrollTop: ($('.top-section').innerHeight() - windowHeight * 0.3)
            });
        });
    });
    var stickyISIHeight = 200;
    var ISICorrection = 0;
    var adjst = windowHeight - (stickyISIHeight + ISICorrection);
    $(document).on('scroll', function () {
        if (($(this).scrollTop() + adjst) >= $('.top-section').innerHeight()) {
            $('#isi-secondary-footer').removeClass('fixed');
            toggleExpandIcon()
        } else {
            toggleExpandIcon(false)
            // $('#scrollicon').removeClass('scrolled');
            $('#isi-secondary-footer').addClass('fixed');
        }
    });
})(jQuery);