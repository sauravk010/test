// Example starter JavaScript for disabling form submissions if there are invalid fields
(function ($) {
  'use strict'
  $(document).ready(function () {
    addRequiredWrapper();

    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')
    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
      .forEach(function (form) {
        form.addEventListener('submit', function (event) {
          if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
          }

          form.classList.add('was-validated')
        }, false)
      });
    // Contact me validation
    $(function () {
      $('select').selectpicker();
    });
    $('#callme-checkbox').on("click", function () {
      if ($(this).prop('checked')) {
        $("#phone-number").prop('required', true);
      }
      else {
        $("#phone-number").prop('required', false);
      }
      addRequiredWrapper();
    });
    $('#contactme-checkbox').on("click", function () {
      if ($(this).prop('checked')) {
        contactMe();
      }
      else {
        contactMe(false)
      }
    });
    // initialize contactme and callme
    if ($('#contactme-checkbox').is(":checked")) {
      contactMe()
      if ($('#callme-checkbox').is(":checked")) {
        $("#phone-number").prop('required', true);
        addRequiredWrapper();
      }
    }
    // Email validation
    // Isvalid mail
    $('#email-id').on('change', function (e) {
      if (IsEmail($(this).val())) {
        $(this).addClass('is-valid').removeClass('is-invalid')
      } else {
        $(this).addClass('is-invalid').removeClass('is-valid')
      }
    });
    // Is mail matching
    $('#confirm-emailid').on('keyup', function (e) {
      if ($(this).val() === $('#email-id').val()) {
        $(this).addClass('is-valid').removeClass('is-invalid')
      } else {
        $(this).addClass('is-invalid').removeClass('is-valid')
      }
    });
    // Modal Styling
    $('#thankyou-modal').on('show.bs.modal', function () {
      $('.contact-main-wrapper').addClass('blur-bg')
    })
    $('#thankyou-modal').on('hide.bs.modal', function () {
      $('.contact-main-wrapper').removeClass('blur-bg')
    })
  });
  function addRequiredWrapper() {
    $('input[required]').closest('.field-wrapper').addClass('required-wrapper');
    $('select[required]').closest('.field-wrapper').addClass('required-wrapper');
    $('input:not([required])').closest('.field-wrapper').removeClass('required-wrapper');
    $('select:not([required])').closest('.field-wrapper').removeClass('required-wrapper');
  }
  function contactMe(status = true) {
    if (status) {
      $('.condition-contact').show();
      $('#city-practice').prop('required', true);
      $('#state-practice').prop('required', true);
      addRequiredWrapper();
    } else {
      $('.condition-contact').hide();
      $('#city-practice').prop('required', false);
      $('#state-practice').prop('required', false);
      $('#emailme-checkbox').prop('checked', false);
      $('#callme-checkbox').prop('checked', false);
    }
  }

  function IsPhone(phone) {
    var regex = /^[0-9\_]{7,20}/;
    if (!regex.test(phone)) {
      return false;
    } else {
      return true;
    }
  }
  function IsEmail(email) {
    var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!regex.test(email)) {
      return false;
    } else {
      return true;
    }
  }
})(jQuery);
