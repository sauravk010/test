<?php
include 'services/contact-submission.php'
?>
<!DOCTYPE html>
<html>

<head>
  <title>Get Connected | <?php echo $settings['site_name']; ?></title>
  <link rel="icon" type="image/x-icon" href="<?php echo $settings['favicon']; ?>">
  <link rel="shortcut icon" href="<?php echo $settings['favicon']; ?>">
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <!-- BootStrap latest compiled and minified JavaScript -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
  <!-- Select Picker latest compiled and minified CSS & JavaScript -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script>
  <!-- Custom Styles and JS -->
  <link rel="stylesheet" type="text/css" href="assets/css/hutchmed.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <script src="assets/js/site.js" type="text/javascript"></script>
  <?php if (isset($_REQUEST['agree-checkbox']) && $form_valid) : ?>
    <script>
      $(document).ready(function() {
        $('#thankyou-modal').modal('show');
      });
    </script>
  <?php endif; ?>
</head>

<body>
  <!-- Modal -->
  <div class="modal fade contact-pageModal" id="thankyou-modal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <h2>Thank you. We'll keep you upto date about SEVSURY</h2>
          <p>if you requested to hear from a HUTCHMED representative,<br> a member of our team will be in touch shortly.</p>
        </div>
        <div class="modal-footer">
          <a href="/hutchmed.html" type="button" class="btn btn-light modal-button">Return to SEVSURY website</a>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal ends -->
  <div class="top-section">
    <div class="header">
      <div class="container">
        <div class="headerTop">
          <p class="site-information">this site is intended for U.S. healthcare professionals </p>
          <div class="header-logo">
            <a href="/" class="logo-link"><img src="assets/images/logo-white.png" class="sevsurvy-logo" alt="logo"></a>
            <!-- <img src="assets/images/fpo.png" alt="fpo" class="header-fpo"> -->
          </div>
          <div class="logo-text">
            <div class="logo-text-row-2">
              <a href="javascript:;" class="release">Press Release</a>
              <a href="javaacript:;" class="information"> Prescribing Information</a>
              <a href="/contact.php" class="logo-callToActionBtn">Get Connected</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="contact-main-wrapper">
    <!-- <div class="blur-backdrop"></div> -->
    <div class="container">
      <div class="contact-title">
        <h2>Get Connected with SEVSURY</h2>
        <h3>Sign up to learn more about SEVSURY</h3>
      </div>
      <form method="post" class="needs-validation" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" novalidate>
        <div class="row">
          <div class="col field-wrapper">
            <label for="first-name" class="form-label">First name</label>
            <input id="first-name" name="first-name" type="text" class="form-control" placeholder="First name" aria-label="First name" value="<?php echo isset($data['first-name']) ? $data['first-name'] : ""; ?>" required>
            <!-- <div class="invalid-feedback">
              Please enter First name.
            </div> -->
          </div>
          <div class="col field-wrapper">
            <label for="last-name" class="form-label">Last name</label>
            <input id="last-name" name="last-name" type="text" class="form-control" placeholder="Last name" aria-label="Last name" value="<?php echo isset($data['last-name']) ? $data['last-name'] : ""; ?>" required>
            <!-- <div class="invalid-feedback">
              Please enter Last name.
            </div> -->
          </div>
        </div>
        <div class="row">
          <div class="col field-wrapper">
            <label for="email-id" class="form-label">Email address</label>
            <input id="email-id" name="email-id" type="text" class="form-control" placeholder="Email address" aria-label="Email address" value="<?php echo isset($data['email-id']) ? $data['email-id'] : ""; ?>" required>
            <!-- <div class="invalid-feedback">
              Please enter a email address
            </div> -->
          </div>
          <div class="col field-wrapper">
            <label for="confirm-emailid" class="form-label">Confirm Email address</label>
            <input id="confirm-emailid" name="confirm-emailid" type="text" class="form-control" placeholder="Confirm Email address" aria-label="Confirm Email address" value="<?php echo isset($data['confirm-emailid']) ? $data['confirm-emailid'] : ""; ?>" required>
            <!-- <div class="invalid-feedback">
              Email address should match
            </div> -->
          </div>
        </div>
        <div class="row">
          <div class="col field-wrapper specDrop-down">
            <label for="speciality-select" class="form-label">Speciality</label>
            <select id="speciality-select" name="speciality-select" class="form-control select-picker style-2" aria-label="Speciality" title="Select one" required>
              <?php foreach ($speciality as $key => $value) : ?>
                <option value="<?php echo $key; ?>" <?php echo isset($data['speciality-select']) && ($data['speciality-select'] == $key) ? 'selected' : ''; ?>><?php echo $value; ?></option>
              <?php endforeach ?>
            </select>
            <!-- <div class="invalid-feedback">
              Please choose a speciality.
            </div> -->
          </div>
        </div>
        <div class="checkbox my-4">
          <div class="col field-wrapper">
            <input type="checkbox" class="form-check-input" id="agree-checkbox" name="agree-checkbox" <?php echo isset($data['agree-checkbox']) && ($data['agree-checkbox'] == 'on') ? 'checked' : ''; ?> required>
            <label class="form-check-label" for="agree-checkbox">By checking this box, I confirm that I am a healthcare professional who manages NET patients in the United States, 18 years of age or older, and a resident of the United States.</label>
            <!-- <div class="invalid-feedback">
              Please check this box to continue.
            </div> -->
          </div>
        </div>
        <div class="checkbox my-4">
          <div class="col field-wrapper">
            <input type="checkbox" class="form-check-input" id="newsletter-checkbox" name="newsletter-checkbox" <?php echo isset($data['newsletter-checkbox']) && ($data['newsletter-checkbox'] == 'on') ? 'checked' : ''; ?>>
            <label class="form-check-label" for="newsletter-checkbox">I would like more information on SEVSURY. I am indicating that I would like to receive emails from HUTCHMED US Corporation. I may opt out at any time. </label>
          </div>
        </div>
        <div class="checkbox my-4">
          <div class="col field-wrapper">
            <input type="checkbox" class="form-check-input" id="contactme-checkbox" name="contactme-checkbox" <?php echo isset($data['contactme-checkbox']) && ($data['contactme-checkbox'] == 'on') ? 'checked' : ''; ?>>
            <label class="form-check-label" for="contactme-checkbox">I would like a HUTCHMED representative to contact me. </label>
          </div>
        </div>
        <div class="ms-3 condition-contact">
          <div class="checkbox mb-4">
            <div class="col field-wrapper">
              <input type="checkbox" class="form-check-input" id="emailme-checkbox" name="emailme-checkbox" <?php echo isset($data['emailme-checkbox']) && ($data['emailme-checkbox'] == 'on') ? 'checked' : ''; ?>>
              <label class="form-check-label" for="emailme-checkbox">Email Me</label>
            </div>
          </div>
          <div class="checkbox my-4">
            <div class="col field-wrapper">
              <input type="checkbox" class="form-check-input" id="callme-checkbox" name="callme-checkbox" <?php echo isset($data['callme-checkbox']) && ($data['callme-checkbox'] == 'on') ? 'checked' : ''; ?>>
              <label class="form-check-label" for="callme-checkbox">Call Me</label>
            </div>
          </div>
          <div class="checkbox phone">
            <div class="field-wrapper">
              <label for="phone-number" class="form-label">Phone Number</label>
              <input id="phone-number" name="phone-number" type="text" class="form-control" placeholder="Phone Number" value="<?php echo isset($data['phone-number']) ? $data['phone-number'] : ""; ?>" aria-label="Phone Number">
              <!-- <div class="invalid-feedback">
                Please enter a Phone Number
              </div> -->
            </div>
          </div>
          <div class="row">
            <div class="col field-wrapper">
              <label for="city-practice" class="form-label">City of Practice</label>
              <input id="city-practice" name="city-practice" type="text" class="form-control" placeholder="City of Practice" value="<?php echo isset($data['city-practice']) ? $data['city-practice'] : ""; ?>" aria-label="City of Practice">
              <!-- <div class="invalid-feedback">
                City of Practice is required
              </div> -->
            </div>
            <div class="col field-wrapper">
              <label for="state-practice" class="form-label">State of Practice</label>
              <select id="state-practice" name="state-practice" class="form-control select-picker style-2" aria-label="State of Practice" title="Select one">
                <?php foreach ($US_states as $key => $value) : ?>
                  <option value="<?php echo $key; ?>" <?php echo isset($data['state-practice']) && ($data['state-practice'] == $key) ? 'selected' : ''; ?>><?php echo $value; ?></option>
                <?php endforeach ?>
              </select>
              <!-- <div class="invalid-feedback">
                Please choose a State.
              </div> -->
            </div>
          </div>
        </div>
        <div class="required-text my-5">
          <div class="field-wrapper">
            <div class="form-text">*indicates required fields</div>
          </div>
        </div>
        <div class="submitBtn">
          <button type="submit" class="btn btn-primary btn-clear-form">Clear Form</button>
          <button type="submit" class="btn btn-primary btn-submit">Submit<img src="assets/images/icon_arrow_right_20px.svg"/></button>
        </div>
      </form>
    </div>
  </div>

</body>
<footer id="main-footer" class="footer-border">
  <div class="container">
    <div class="contact-details">
      <a href="javascript:;">Contact Us</a>|
      <a href="javascript:;" class="seprator-line">Terms of Use</a>|
      <a href="javascript:;">Privacy Policy</a>
    </div>
    <div class="footer-logo">
      <img src="assets/images/HUTCHMED LOGO.png" class="hutchmed-logo" alt="logo">
      <p class="copyright">© 2022 HUTCHMED US Corporation. US-COM-SEV-00056 Jan ’22.</p>
    </div>
  </div>
</footer>

</html>