'use strict';
var gulp = require('gulp');
var sass = require('gulp-sass');
var uglify = require('gulp-uglify');
var autoPrefixer = require('gulp-autoprefixer');

// Define tasks after requiring dependencies

function styleTask() {
    return (
        gulp
        .src(['assets/css/hutchmed.scss'])
        .pipe(sass({
            outputStyle: 'compressed'
        }))
        .on("error", sass.logError)
        .pipe(autoPrefixer({
            overrideBrowserslist: ['last 2 versions'],
            cascade: false
        }))
        .pipe(gulp.dest("assets/css"))
    );
}

function jsTask() {
    return (
        gulp
        .src(["assets/js/*.js"])
        .pipe(uglify())
        .pipe(gulp.dest("js"))
    );
}

function watch() {
    gulp.watch('assets/css/hutchmed.scss', styleTask);
    gulp.watch('assets/js/*.js', jsTask);
}

exports.style = styleTask;
exports.jsTask = jsTask;
exports.watch = watch;