<?php

use Kint\Kint;

include 'vendor/autoload.php';
require 'settings/conf.php';
require 'settings/logger.php';
include 'services/mailer.php';

$US_states = [
  'AL' => 'AL',
  'AK' => 'AK',
  'AZ' => 'AZ',
  'AR' => 'AR',
  'CA' => 'CA',
  'CO' => 'CO',
  'CT' => 'CT',
  'DE' => 'DE',
  'FL' => 'FL',
  'GA' => 'GA',
  'HI' => 'HI',
  'ID' => 'ID',
  'IL' => 'IL',
  'IN' => 'IN',
  'IA' => 'IA',
  'KS' => 'KS',
  'KY' => 'KY',
  'LA' => 'LA',
  'ME' => 'ME',
  'MD' => 'MD',
  'MA' => 'MA',
  'MI' => 'MI',
  'MN' => 'MN',
  'MS' => 'MS',
  'MO' => 'MO',
  'MT' => 'MT',
  'NE' => 'NE',
  'NV' => 'NV',
  'NH' => 'NH',
  'NJ' => 'NJ',
  'NM' => 'NM',
  'NY' => 'NY',
  'NC' => 'NC',
  'ND' => 'ND',
  'OH' => 'OH',
  'OK' => 'OK',
  'OR' => 'OR',
  'PA' => 'PA',
  'RI' => 'RI',
  'SC' => 'SC',
  'SD' => 'SD',
  'TN' => 'TN',
  'TX' => 'TX',
  'UT' => 'UT',
  'VT' => 'VT',
  'VA' => 'VA',
  'WA' => 'WA',
  'WV' => 'WV',
  'WI' => 'WI',
  'WY' => 'WY'
];

$speciality = [
  'oncologist' => 'Oncologist',
  'endocrinologist' => 'Endocrinologist',
  'gastroencrologist' => 'Gastroencrologist',
  'surgeon' => 'Surgeon',
  'primary care' => 'Primary Care',
  'np/pa' => 'NP/PA',
  'other' => 'Other',
];
$form_valid = true;
// Initialize error array.
$errors = [];
$data = $_REQUEST;
if (isset($_REQUEST['agree-checkbox'])) {
  if (!empty($data['email-id']) && !empty($data['confirm-emailid']) && ($data['email-id'] != $data['confirm-emailid'])) {
    $errors['confirm-emailid'] = TRUE;
  }
  if (!empty($data['email-id'])) {
  }
  $pattern = "/^[0-9\_]{7,20}/";
  if (!empty($data['phone-number']) && !preg_match($pattern, $data['phone-number'])) {
    $errors['phone-number'] = TRUE;
  }
  $pattern = "/^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/";
  if (!empty($data['email-id']) && !preg_match($pattern, $data['email-id'])) {
    $errors['email-id'] = TRUE;
  }
}
if (count($errors) > 0) {
  $form_valid = false;
} elseif (isset($_REQUEST['agree-checkbox']) && $_REQUEST['agree-checkbox'] == "on") {
  $var_array = [
    "first-name" => $data["first-name"],
    "last-name" => $data["last-name"],
    "email-id" => $data["email-id"],
    "speciality-select" => $data["speciality-select"],
    "newsletter-checkbox" => isset($data["newsletter-checkbox"]) ? $data["newsletter-checkbox"] : "Off",
    "emailme-checkbox" => isset($data["emailme-checkbox"]) ? $data["emailme-checkbox"] : "Off",
    "callme-checkbox" => isset($data["callme-checkbox"]) ? $data["callme-checkbox"] : "Off",
    "phone-number" => $data["phone-number"],
    "city-practice" => $data["city-practice"],
    "state-practice" => $data["state-practice"],
  ];

  $from_email = $settings['hutchmed_mail'];
  $to_email = $settings['hutchmed_mail'];
  $subject = "From HUTCHMED";
  $email_body = getEmailTemplate($var_array);
  if ($settings['enable_mail']) {
    $mailsent = customSendMail($from_email, $to_email, $email_body, $subject);

    // $mailsent = true;
    // if ($mailsent && $settings['enable_db']) {
    //   // Create connection
    //   $connection = new mysqli($settings['db_host'], $settings['db_user'], $settings['db_password'], $settings['db_database']);
    //   if (!$connection) {
    //     custom_logger("Database Connection Failed" . mysqli_error($connection));
    //   }
    //   // // Check connection
    //   // if ($conn->connect_error) {
    //   // die("Connection failed: " . $conn->connect_error);
    //   // }

    //   $email_body = urlencode($email_body);
    //   $email_body = serialize($email_body);
    //   // $email_body = "sss";
    //   $query = "INSERT INTO `contact_details` (from_email, to_email, subject, email_body) VALUES ('$from_email','$to_email','$subject','$email_body')";
    //   // $result = mysqli_query($connection, $query);
    //   // if ($connection->query($query) === TRUE) {
    //   // custom_logger("New record created successfully");
    //   // } else {
    //   // Kint::dump($query);
    //   // Kint::dump($connection->error);
    //   // custom_logger("Error: " . $query . "<br>" . $connection->error);
    //   // }
    //   $sql = "SELECT * FROM contact_details";
    //   $result = $connection->query($sql);

    //   if ($result->num_rows > 0) {
    //     // output data of each row
    //     while ($row = $result->fetch_assoc()) {
    //       Kint::dump($row['email_body']);
    //       $unserialize = unserialize($row['email_body']);
    //       Kint::dump($unserialize);
    //       Kint::dump(urldecode($unserialize));
    //       // echo "id: " . $row["id"] . " - Name: " . $row["firstname"] . " " . $row["lastname"] . "<br>";
    //     }
    //   } else {
    //     echo "0 results";
    //   }
    //   exit;

    //   $unserialize = unserialize($email_body);
    //   Kint::dump($unserialize);
    //   Kint::dump(urldecode($unserialize));

    //   $connection->close();
    //   // Kint::dump(mysqli_query($connection, $query));
    //   // exit;
    //   custom_logger("Database entry done.");
    // }
  }
}
