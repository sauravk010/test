<?php

use Kint\Kint;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

//Create an instance; passing `true` enables exceptions
function getEmailTemplate($var_array, $template_file = "./email-templates/post-contact-mail.html") {
  include 'settings/conf.php';
  $file_content = file_get_contents($template_file);
  $rplc_cnt = 0;
  foreach ($var_array as $key => $value) {
    $file_content = str_replace('{{' . $key . '}}', $value, $file_content, $rplc_cnt);
  }
  $file_content = str_replace('{{site-logo}}', $settings['mail_logo'], $file_content, $rplc_cnt);
  // $pattern = '/\{\{([a-zA-Z0-9_\s\.\-\+\}\}])+/';
  // echo preg_replace($pattern, '', $file_content);
  return $file_content;
}
function customSendMail($from, $to, $body, $subject = "From HUTCHMED", $from_name = "HUTCHMED", $to_name = "HUTCHMED Mail") {
  include 'settings/conf.php';
  require_once 'settings/logger.php';
  $mail = new PHPMailer(true);

  try {
    //Server settings
    $mail->SMTPDebug = $settings['smtp_debug'];
    $mail->isSMTP();
    $mail->Host = $settings['smtp_host'];
    $mail->SMTPAuth = true;
    $mail->Username = $settings['smtp_username'];
    $mail->Password = $settings['smtp_password'];
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = $settings['smtp_port'];

    //From and To
    $mail->setFrom($from, $from_name);
    $mail->addAddress($to, $to_name);

    //Content
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body    = $body;
    // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $return = $mail->send();
    custom_logger("Message has been sent");
    return $return;
  } catch (Exception $e) {
    custom_logger("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
  }
}
