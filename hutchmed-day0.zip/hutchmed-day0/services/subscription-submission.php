<?php

use Kint\Kint;

include 'vendor/autoload.php';
require 'settings/conf.php';
include 'services/mailer.php';

// Kint::dump($GLOBALS);
// Kint::dump($settings['enable_mail']);
// exit;
if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] && isset($_REQUEST['param'])) {
  if ($_REQUEST['param'] != '') {
    $var_array = [
      "email" => $_REQUEST['param'],
      "contact-preference" => $_REQUEST['contact-preference'],
    ];
    $body = getEmailTemplate($var_array, "./email-templates/contact-preference-mail.html");
    if ($settings['enable_mail']) {
      customSendMail($settings['hutchmed_mail'], $settings['hutchmed_mail'], $body, "Contact preference updated", "HUTCHMED subscription updater");
    }
  }
}
