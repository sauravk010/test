<?php
$settings = [];
$settings['site_name'] = "Sevsury ";
$settings['site_url'] = "https://hmd-day0.lndo.site";
$settings['favicon'] = "assets/images/favicon.ico";
$settings['logo'] = "assets/images/logo.png";

// Mailer configuration
$settings['enable_mail'] = false;
$settings['mail_logo'] = "https://www.hutch-med.com/wp-content/themes/chimed/images/brand-guidelines-update-2021/logo-v2.png";
$settings['hutchmed_mail'] = "razeem.ahmad@gmail.com";

// Mailer settings
$settings['smtp_debug'] = 0;
$settings['smtp_mailer'] = 'smtp';
$settings['smtp_host'] = 'smtp.gmail.com';
$settings['smtp_username'] = '';
$settings['smtp_password'] = '';
$settings['smtp_port'] = 465;

// Mailer settings
$settings['enable_db'] = true;
$settings['db_host'] = "database";
$settings['db_database'] = 'lamp';
$settings['db_user'] = 'lamp';
$settings['db_password'] = 'lamp';

if (file_exists('settings/conf.local.php')) {
  include 'settings/conf.local.php';
}
if (file_exists('settings/conf.prod.php')) {
  include 'settings/conf.prod.php';
}
