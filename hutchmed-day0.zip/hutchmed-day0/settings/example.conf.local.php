<?php
// Mailer configuration
$settings['enable_mail'] = false;

// Mailer settings
$settings['smtp_debug'] = 0;
$settings['smtp_mailer'] = 'smtp';
$settings['smtp_host'] = '';
$settings['smtp_username'] = '';
$settings['smtp_password'] = '';
$settings['smtp_port'] = 465;

// Mailer settings
$settings['enable_db'] = true;
$settings['db_host'] = "";
$settings['db_database'] = '';
$settings['db_user'] = '';
$settings['db_password'] = '';

