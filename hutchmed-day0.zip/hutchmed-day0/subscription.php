<?php
include 'services/subscription-submission.php'
?>
<!DOCTYPE html>
<html>

<head>
  <title>Update Contact Preferences | <?php echo $settings['site_name']; ?></title>
  <link rel="icon" type="image/x-icon" href="<?php echo $settings['favicon']; ?>">
  <link rel="shortcut icon" href="<?php echo $settings['favicon']; ?>">
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <!-- BootStrap latest compiled and minified JavaScript -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
  <!-- Select Picker latest compiled and minified CSS & JavaScript -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script>
  <!-- Custom Styles and JS -->
  <link rel="stylesheet" type="text/css" href="assets/css/hutchmed.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <script src="assets/js/site.js" type="text/javascript"></script>
  <?php if (isset($_REQUEST['submitted'])) : ?>
    <script>
      $(document).ready(function() {
        $('#thankyou-modal').modal('show');
      });
    </script>
  <?php endif; ?>
</head>

<body>
  <!-- Modal -->
  <div class="modal fade contact-pageModal subscriptionModal" id="thankyou-modal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <h2>Thank you.<br> Your preferences have been updated</h2>`
        </div>
        <div class="modal-footer">
          <a href="/hutchmed.html" type="button" class="btn btn-light">Return to SEVSURY website</a>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal Ends -->
  <div class="top-section subTop">
    <div class="header">
      <div class="container">
        <div class="headerTop">
          <p class="site-information">this site is intended for U.S. healthcare professionals </p>
          <div class="header-logo">
            <a href="javascript:;" class="logo-link"><img src="assets/images/logo-white.png" class="sevsurvy-logo" alt="logo"></a>
            <!-- <img src="assets/images/fpo.png" alt="fpo" class="header-fpo"> -->
          </div>
          <div class="logo-text">
            <div class="logo-text-row-2">
              <a href="javascript:;" class="release">Press Release</a>
              <a href="javaacript:;" class="information"> Prescribing Information</a>
              <a href="javascript:;" class="logo-callToActionBtn">Get Connected</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="subscription">
    <div class="blur-backdrop"></div>
    <div class="container">
      <form method="post" class="needs-validation" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" novalidate>
        <div class="row">
          <div class="col-lg-12">
            <h2>Contact preferences</h2>
            <?php if (isset($_GET['mail'])) : ?>
              <h3>You are subscribed as: <div><span class="color-purple">[</span>
                  <span><?php echo isset($_GET['mail']) ? $_GET['mail'] : ''; ?></span>
                  <span class="color-purple">]</span>
                </div>
              </h3>
            <?php endif; ?>
            <h3>We want to stay in touch but only in ways that work for you. Please choose your email options below:</h3>
          </div>
          <div class="col-lg-12">
            <h4>I would like to receive emails from HUTCHMED</h4>
          </div>
          <div class="form-check col-lg-12">
            <input class="form-check-input" type="radio" name="contact-preference" id="contact-preference-1" value="Monthly">
            <label class="form-check-label" for="contact-preference-1">
              Monthly
            </label>
          </div>
          <div class="form-check col-lg-12">
            <input class="form-check-input" type="radio" name="contact-preference" id="contact-preference-2" value="Bi anually">
            <label class="form-check-label" for="contact-preference-2">
              Bianually
            </label>
          </div>
          <div class="form-check col-lg-12">
            <input class="form-check-input" type="radio" name="contact-preference" id="contact-preference-3" value="Remove me">
            <label class="form-check-label" for="contact-preference-3">
              Remove me from hutchmed email list
            </label>
          </div>
          <input type="hidden" name="submitted" value="1">
          <input type="hidden" name="param" value="<?php echo isset($_GET['mail']) ? $_GET['mail'] : '';  ?>">
          <div class="SubBtn-submit">
            <button type="submit" class="btn btn-primary">Submit <img src="assets/images/icon_arrow_right_20px.svg" /></button>
          </div>
        </div>
      </form>
    </div>
  </div>
</body>

<footer id="main-footer" class="mt-5">
  <div class="container">
    <div class="contact-details">
      <a href="javascript:;">Contact Us</a>|
      <a href="javascript:;" class="seprator-line">Terms of Use</a>|
      <a href="javascript:;">Privacy Policy</a>
    </div>
    <div class="footer-logo">
      <img src="assets/images/HUTCHMED LOGO.png" class="hutchmed-logo" alt="logo">
      <p class="copyright">© 2022 HUTCHMED US Corporation. US-COM-SEV-00056 Jan ’22.</p>
    </div>
  </div>
</footer>

</html>